ClearView PvP & Clarity
Drop the zip into .minecraft/resourcepacks (Java 1.21.9+).
Short swords (first person), clean crosshair, no pumpkin blur overlay.
